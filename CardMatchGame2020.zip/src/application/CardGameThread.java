package application;

public class CardGameThread extends Thread 
{
	RootController m_controller;
	public CardGameThread(RootController controller)
	{
		super();
		m_controller = controller;
	}
	public void run()
	{
		while(true)
		{
			try 
			{
				Thread.sleep(10);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			m_controller.checkMatch();
		}
	}
	
}
