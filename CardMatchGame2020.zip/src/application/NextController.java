package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class NextController implements Initializable {

	@FXML ImageView card00, card01, card02, card03, card04, card05, card06, card07, card08, card09, card10, card11, card12, card13, card14, card15;
	@FXML Label lbl_top;
	@FXML ImageView backimg;
	ImageView[][] image_obj = new ImageView[4][4];	//[]�ȿ��� ������ ������. 3��2���� �ƴ�
	
	public static final int STATE_READY = 0;		//0�̸� �غ� 1�̸� ������
	public static final int STATE_GAME = 1;			//static final�� ���
	public static final int STATE_END = 2;
	public int m_state = STATE_READY;
	
	int m_column=4, m_row=4;
	Card m_Shuffle1, m_Shuffle2;
	Card m_Card[][] = new Card[m_column][m_row];				//ī��迭 ����

	
//	private Stage primaryStage;									//�ٸ� fxml ���������� �����
//	public void setPrimaryStage(Stage primaryStage) 
//	{
//		this.primaryStage = primaryStage;
//	}
		
	@Override
	public void initialize(URL location, ResourceBundle resources) 
	{
		image_obj[0][0] = card00;
		image_obj[1][0] = card01;
		image_obj[2][0] = card02;
		image_obj[3][0] = card03;
		image_obj[0][1] = card04;
		image_obj[1][1] = card05;
		image_obj[2][1] = card06;
		image_obj[3][1] = card07;
		image_obj[0][2] = card08;
		image_obj[1][2] = card09;
		image_obj[2][2] = card10;
		image_obj[3][2] = card11;
		image_obj[0][3] = card12;
		image_obj[1][3] = card13;
		image_obj[2][3] = card14;
		image_obj[3][3] = card15;
		
		Card_Shuffle(m_column, m_row);
		OnDraw();
		NextGameThread thread = new NextGameThread(this);
		thread.start();
	}
	
	public void Card_Shuffle(int column, int row)
	{
		for(int y=0; y<row; y++)
		{
			for(int x=0; x<column; x++)
			{
				m_Card[x][y] = new Card((y*column +x)%8);				//0~5���� �ѹ��� �������Ϸ��� y*column+x | ī�尹���� �������� %n ���� �������� �̿�
			}
		}
		for(int i=0; i<100; i++)
		{
			int x = (int)(Math.random()*column);								//Math.�Լ� : �����Լ��� ���Ե� java �⺻Ŭ����
			int y = (int)(Math.random()*row);
			m_Shuffle1 = m_Card[x][y];
			x = (int)(Math.random()*column);							
			y = (int)(Math.random()*row);
			m_Shuffle2 = m_Card[x][y];
			int temp = m_Shuffle1.m_image;
			m_Shuffle1.m_image=m_Shuffle2.m_image;
			m_Shuffle2.m_image = temp;
		}
		m_Shuffle1 = null;
		m_Shuffle2 = null;
	}

	public void OnDraw()
	{
		if(m_state == STATE_READY)
		{
			All_Card_View();
		}
		else if(m_state == STATE_GAME)
		{
			for(int y=0; y<m_row; y++)
			{
				for(int x=0; x<m_column; x++)
				{
					if(m_Card[x][y].m_state == Card.CARD_CLOSE)
					{
						image_obj[x][y].setImage(new Image(getClass().getResource("image/whos.jpg").toString()));
					}
					else 
					{
						View_Front_Image(x,y);
					}
				}
			}
		}
	}
	
	public void All_Card_View()
	{
		for(int y=0; y<m_row; y++)
		{
			for(int x=0; x<m_column; x++)
			{
				View_Front_Image(x,y);
			}
		}
	}
	
	public void View_Front_Image(int x, int y)
	{
		switch(m_Card[x][y].m_image)
		{
		case Card.IMG_0 : image_obj[x][y].setImage(new Image(getClass().getResource("image/cheong.jpg").toString()));
			break;
		case Card.IMG_1 : image_obj[x][y].setImage(new Image(getClass().getResource("image/geoseok.jpg").toString()));
			break;
		case Card.IMG_2 : image_obj[x][y].setImage(new Image(getClass().getResource("image/geumja.jpg").toString()));
			break;
		case Card.IMG_3 : image_obj[x][y].setImage(new Image(getClass().getResource("image/gon.jpg").toString()));
			break;
		case Card.IMG_4 : image_obj[x][y].setImage(new Image(getClass().getResource("image/gyunwoo.jpg").toString()));
			break;
		case Card.IMG_5 : image_obj[x][y].setImage(new Image(getClass().getResource("image/hwadam.jpg").toString()));
			break;
		case Card.IMG_6 : image_obj[x][y].setImage(new Image(getClass().getResource("image/jayoon.jpg").toString()));
			break;
		case Card.IMG_7 : image_obj[x][y].setImage(new Image(getClass().getResource("image/yennycall.jpg").toString()));
			break;
		}
	}
	
	public void OnMouseClickedStart(MouseEvent event)				//���콺�̺�Ʈ�� x,y��ǥ������ double�� �����´�
	{
		if(m_state == STATE_READY)									//���ӻ��°� �غ�ܰ��
		{
			m_state = STATE_GAME;									//���ӻ��·� ���۴ܰ�� �ٲٰ�
			all_card_close();										//ī��� ������
			OnDraw();												//ī�带 ����
		}
		else if(m_state == STATE_END)
		{	
			lbl_top.setVisible(true);
			backimg.setVisible(false);
			lbl_top.setText("Game Clear");							//����Ŭ����
			
//			Card_Shuffle(m_column,m_row);							//���ѹݺ�
//			m_state = STATE_READY;
		}
	}
/*	
	public void handleCustom(ActionEvent e) 									
	{
		Stage last = new Stage(StageStyle.UTILITY);
		last.initModality(Modality.WINDOW_MODAL);
		last.initOwner(primaryStage);											
		last.setTitle("�˸�");
		
		try 																	
		{																	
			Parent parent = FXMLLoader.load(											
					getClass().getResource("clear.fxml"));
			Button btnOK = (Button)parent.lookup("#btn_ok");
			btnOK.setOnAction(event->last.close());
			Scene scene = new Scene(parent);
			last.setScene(scene);
			last.show();
		} 
		catch (IOException x) 
		{
			x.printStackTrace();
		}
	}
*/
	public void OnMouseClickedImageView(MouseEvent event)
	{
		if (m_Shuffle1 != null && m_Shuffle2 != null) return;
		for(int y=0; y<m_row; y++)
		{
			for(int x=0; x<m_column; x++)
			{
				if(image_obj[x][y] == event.getSource())
				{
					if(m_Card[x][y].m_state == Card.CARD_CLOSE && m_Shuffle2==null)				//ī��� ���������� �϶��� �ι�° ī�尡 ����������� ���ð���
					{
						m_Card[x][y].m_state = Card.CARD_PLAYEROPEN;
						if(m_Shuffle1 == null)
						{
							m_Shuffle1=m_Card[x][y];
						}
						else
						{
							m_Shuffle2=m_Card[x][y];
						}
						OnDraw();
					}
					return;
				}
			}
		}
	}
	
	public void all_card_close()
	{
		for(int y=0; y<m_row; y++)
		{
			for(int x=0; x<m_column; x++)
			{
				m_Card[x][y].m_state=Card.CARD_CLOSE;
			}
		}
	}
	
	public void checkMatch()
	{
		if(m_Shuffle1 == null || m_Shuffle2 == null) return;
		if(m_Shuffle1.m_image == m_Shuffle2.m_image)
		{
			m_Shuffle1.m_state = Card.CARD_MATCH;
			m_Shuffle2.m_state = Card.CARD_MATCH;
			m_Shuffle1=null;
			m_Shuffle2=null;
			for(int y=0; y<m_row; y++)
			{
				for(int x=0; x<m_column; x++)
				{
					if(m_Card[x][y].m_state != Card.CARD_MATCH)
					{
						OnDraw();
						return;
					}
				}
			}
			m_state = STATE_END;
		}
		else
		{
			try 
			{
				Thread.sleep(800);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			m_Shuffle1.m_state = Card.CARD_CLOSE;
			m_Shuffle2.m_state = Card.CARD_CLOSE;
			m_Shuffle1=null;
			m_Shuffle2=null;
		}
		OnDraw();	
	}

}
