package application;

public class NextGameThread extends Thread {

	NextController n_controller;
	public NextGameThread(NextController controller)
	{
		super();
		n_controller = controller;
	}
	public void run()
	{
		while(true)
		{
			try 
			{
				Thread.sleep(10);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
			n_controller.checkMatch();
		}
	}
	
}
